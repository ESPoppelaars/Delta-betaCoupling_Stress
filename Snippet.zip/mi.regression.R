# Takes a multiply-imputed regression model and pools and returns a list of the results
# (including regression coefficients, variance-inflation factors, partial correlations, and Bayes Factors)

# Argument 'fit.lm.imp' is a lm.mids function with class mipo.summary.
# Argument 'mod' is an integer to signify the model number.
# Argument 'dependant' is a string signifying the dependant variable.
# Argument 'Data' is a multiply imputed dataset of class mids.
# Argument 'results.list' (including: lm.table, corrs, multicol.table, rsqr.imp) is optional.

mi.regression <- function(fit.lm.imp, mod, dependant, Data, results.list) {
  
  ## Pool regression results
  pool.lm.imp <- mice::pool(fit.lm.imp) # Pool
  pool.rsqr.imp <- mice::pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
  pool.rsqr.imp[, "model"] <- mod # Add model number
  sum.lm.imp <- summary(pool.lm.imp) # Summary
  sum.lm.imp[, "Model"] <- mod # Save the lm model number
  sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
  sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
  sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
  
  ## Check multicollinearity
  multicol <- list(NA) # Initialize results list
  # Compute VIF for each variable and imputed dataset
  for (i in 1:length(fit.lm.imp$analyses)) {
    multicol[[i]] <- car::vif(fit.lm.imp$analyses[[i]])
  }
  # Put all VIF's into dataframe
  multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
  for (i in 1:nrow(multicol.table.1)) {
    for (j in 1:ncol(multicol.table.1))
      multicol.table.1[i, j] <- multicol[[j]][[i]]
  }
  rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
  # Compute range of VIFs per variable
  multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
  multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
  multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
  multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
  rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
  multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
  multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
  rownames(multicol.table.2) <- NULL # Reset rownames
  multicol.table.2[ , "model"] <- mod # Save model name
  
  ## Partial correlations
  # Get predictor variable names
  a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
  a <- a[2] # Select only the actual call
  b <- strsplit(a, " ") # Split the call on spaces to get individual variables
  c <- unlist(b) # Unlist to get character vectors
  d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
  e <- d[-c(1)] # Remove the first entry
  f <- unique(e) # Remove double entries
  pred <- f
  # Loop for all variables in the regression results, skipping the intercept
  corr <- list(NA) # Initialize results list
  for (i in 1:length(pred)) {
    # Compute correlation between dependent variable and single predictor, correcting for all other predictors
    form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
    corr.temp <- miceadds::micombine.cor(Data, variables = c(dependant, pred[i]), 
                               partial = as.formula(paste("~", form)))
    corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
  }
  # Put the correlation results in a table
  # Extract results from list
  corr.table <- sapply(corr, function(x) {
    c(var1 = levels(x$variable1)[1],
      var2 = levels(x$variable1)[2],
      rho = x$r,
      p.value = x$p)
  })
  # Save the results as a dataframe
  corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
  corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
    lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
  corr.table[, "cohen.d"] <- psych::r2d(corr.table[, "rho"]) # Compute cohen's d
  corr.table[, "Model"] <- mod # Save the lm model number
  
  ## Bayes factors
  # Initialize variables
  Data_long <- mice::complete(Data, action = "long") # Transform mids into long dataset
  colnames(Data_long)[1] <- "imp" # Change the ".imp" variable into "imp"
  m <- Data$m # Number of imputions
  n.obs <-Data_long %>% dplyr::filter(imp == 1) %>% nrow() # Numbers of observations in the imputed dataset
  BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
  varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
  est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
  # Loop over all imputed datasets
  for (j in 1:m) { # For all imputed datasets
    subdata <- Data_long %>% dplyr::filter(imp == j) # Select imputed Data_long
    BF <- BayesFactor::generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                        data = subdata, whichModels = "bottom", progress = FALSE)
    BFest[, j] <- BayesFactor::extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
    # Calculate the standard error of the estimate per variable (necessary for pooling)
    for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
      if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
        Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
        varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
          n.obs 
      } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
        Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
        varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
          n.obs 
      } else { # For 'normal' variables
        varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
          n.obs 
      }
    }
  }
  # Pool the descriptives into one estimate with three decimals for all vars
  for (i in 1:nrow(sum.lm.imp)) { # For every variable
    est[i, 1] <- mice::pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
  }
  # Add bayes factors to dataframe
  sum.lm.imp[, "BF"] <- est
  # Save results
  rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
  if (!missing(results.list)) { # Check whether previous results have been saved yet
    lm.table <- rbind(results.list[[1]], sum.lm.imp) # Save regression table
    corrs <- rbind(results.list[[2]], corr.table) # Save correlation table
    multicol.table <- rbind(results.list[[3]], multicol.table.2) # Save multicollinearity
    rsqr.imp <- rbind(results.list[[4]], pool.rsqr.imp) # Save R-squared results
  } else { # Otherwise, create new variables
    lm.table <- sum.lm.imp # Save regression table
    corrs <- corr.table # Save correlation table
    multicol.table <- multicol.table.2 # Save multicollinearity
    rsqr.imp <- pool.rsqr.imp # Save R-squared results
  }
  
  ## Return a list with the results
  results.list <- list(lm.table, corrs, multicol.table, rsqr.imp)
  return(results.list) 
}

