# Regressions -------------------------------------------------------------

## Description
# Standardizes variables, calculates eight multiple linear regression models from multiply imputed data 
# to predict delta-beta coupling from other stress responses (and in addition, 
# calculates variance-inflation factors, partial correlations, and Bayes factors)
# and exports the results to Excel.


## Packages
library(mice) # For analyzing imputed data (functions: lm.mids, complete, pool, pool.r.squared, and pool.scalar)
library(miceadds) # For analyzing imputed data (functions: micombine.cor, datlist_create, and scale_datlist)
library(magrittr) # For piping (function: %>%)
library(dplyr) # For data manipulation (function: filter)
library(car) # For variance inflation  test (function: vif)
library(xlsx) # For exporting to excel (function: write.xlsx)
library(psych) # For converting correlation coefficients to cohen's d (function: r2d)
library(BayesFactor) # For Bayesian statistics (functions: generalTestBF, and extractBF)
source('cohen.d.magnitude.R') # Custom function to check the magnitude of Cohen's d values
source('p.value.sig.R') # Custom function to check the significance of p.values
source('BF.evidence.R') # Custom function to check the interpretation of Bayes Factors
source('mi.regression.R') # Custom function to calculate the multiple linear regressions


## Load data
load("SET_CFC.outl.del.imp.RData")
Data <- miceadds::datlist_create(SET_CFC.outl.del.imp) # Create a datlist
Data.list <- miceadds::scale_datlist(Data, # Standardize selected variables with a mean of 0 and standard deviation of 1
                           orig_var = c("RS_Frontal_Avg_dPAC_Z", "react_Frontal_Avg_dPAC_Z",
                                        "RS_Frontal_Avg_AAC_R", "react_Frontal_Avg_AAC_R",
                                        "RS_Parietal_Avg_dPAC_Z", "react_Parietal_Avg_dPAC_Z",
                                        "RS_Parietal_Avg_AAC_R", "react_Parietal_Avg_AAC_R",
                                        "LSAS", "Anx.1", "anx.react",
                                        "PEP.2", "pep.react",
                                        "RSA.2", "rsa.react",
                                        "RR.2", "rr.react",
                                        "Cortisol.1.log", "cort.react",
                                        "EnglishCompetence"), 
                           trafo_var = c("ZRS_Frontal_Avg_dPAC_Z", "Zreact_Frontal_Avg_dPAC_Z", # Ignore logged events
                                         "ZRS_Frontal_Avg_AAC_R", "Zreact_Frontal_Avg_AAC_R",
                                         "ZRS_Parietal_Avg_dPAC_Z", "Zreact_Parietal_Avg_dPAC_Z",
                                         "ZRS_Parietal_Avg_AAC_R", "Zreact_Parietal_Avg_AAC_R",
                                         "ZLSAS", "ZAnx.1", "Zanx.react",
                                         "ZPEP.2", "Zpep.react",
                                         "ZRSA.2", "Zrsa.react",
                                         "ZRR.2", "Zrr.react",
                                         "ZCortisol.1.log", "Zcort.react",
                                         "ZEnglishCompetence"))
Data <- datlist2mids(Data.list) # Convert datlist back to a mids


### Regression models

### Model 1
# Predicts baseline frontal phase-amplitude coupling from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 1
## Specify dependant variable for partial correlations
dependant <- "ZRS_Frontal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- mice::lm.mids(ZRS_Frontal_Avg_dPAC_Z ~ ZLSAS + ZAnx.1 + ZPEP.2 + 
                            ZRSA.2 + ZRR.2 + ZCortisol.1.log, data = Data)
## Run mi.regression function and create new result variables
results.list <- mi.regression(fit.lm.imp, mod, dependant, Data)

### Model 2
# Predicts baseline parietal phase-amplitude coupling from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 2
## Specify dependant variable for partial correlations
dependant <- "ZRS_Parietal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- mice::lm.mids(ZRS_Parietal_Avg_dPAC_Z ~ ZLSAS + ZAnx.1 + ZPEP.2 + 
                            ZRSA.2 + ZRR.2 + ZCortisol.1.log, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 3
# Predicts baseline frontal amplitude-amplitude correlation from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 3
## Specify dependant variable for partial correlations
dependant <- "ZRS_Frontal_Avg_AAC_R"
## Fit model
fit.lm.imp <- mice::lm.mids(ZRS_Frontal_Avg_AAC_R ~ ZLSAS + ZAnx.1 + ZPEP.2 + 
                            ZRSA.2 + ZRR.2 + ZCortisol.1.log, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 4
# Predicts baseline parietal amplitude-amplitude correlation from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 4
## Specify dependant variable for partial correlations
dependant <- "ZRS_Parietal_Avg_AAC_R"
## Fit model
fit.lm.imp <- mice::lm.mids(ZRS_Parietal_Avg_AAC_R ~ ZLSAS + ZAnx.1 + ZPEP.2 + 
                            ZRSA.2 + ZRR.2 + ZCortisol.1.log, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 5
# Predicts frontal phase-amplitude coupling reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 5
## Specify dependant variable for partial correlations
dependant <- "Zreact_Frontal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- mice::lm.mids(Zreact_Frontal_Avg_dPAC_Z ~ ZLSAS +Zanx.react + Zpep.react + 
                            Zrsa.react + Zrr.react + Zcort.react, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 6
# Predicts parietal phase-amplitude coupling reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 6
## Specify dependant variable for partial correlations
dependant <- "Zreact_Parietal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- mice::lm.mids(Zreact_Parietal_Avg_dPAC_Z ~ ZLSAS +Zanx.react + Zpep.react + 
                            Zrsa.react + Zrr.react + Zcort.react, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 7
# Predicts frontal amplitude-amplitude correlation reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 7
## Specify dependant variable for partial correlations
dependant <- "Zreact_Frontal_Avg_AAC_R"
## Fit model
fit.lm.imp <- mice::lm.mids(Zreact_Frontal_Avg_AAC_R ~ ZLSAS + Zanx.react + Zpep.react + 
                            Zrsa.react + Zrr.react + Zcort.react, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Model 8
# Predicts parietal amplitude-amplitude correlation reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 8
## Specify dependant variable for partial correlations
dependant <- "Zreact_Parietal_Avg_AAC_R"
## Fit model
fit.lm.imp <- mice::lm.mids(Zreact_Parietal_Avg_AAC_R ~ ZLSAS + Zanx.react + Zpep.react + 
                            Zrsa.react + Zrr.react + Zcort.react, data = Data)
## Run mi.regression function and append new results to previous results
results.list <- mi.regression(fit.lm.imp,mod, dependant, Data, results.list)


### Export results
# For R-squared
rsqr.imp <- results.list[[4]]
rownames(rsqr.imp) <- NULL # Reset rownames
rsqr.imp <- rsqr.imp[, -4] # Remove fmi column
xlsx::write.xlsx(rsqr.imp, "lm.rsqr_SET_CFC.outl.del.imp.xlsx") # Export R-squared results
# For VIF
multicol.table <- results.list[[3]]
rownames(multicol.table) <- NULL # Reset rownames
multicol.table <- multicol.table[-c(grep("Zrr", multicol.table[, "var"], ignore.case = TRUE)), ] # Remove RR from results
multicol.table[I(nrow(multicol.table)+1), "min_VIF"] <- multicol.table[, "min_VIF"] %>% min() # Add overall min in a new row
multicol.table[nrow(multicol.table), "max_VIF"] <- multicol.table[-nrow(multicol.table), "max_VIF"] %>% max() # Add overall max
multicol.table[nrow(multicol.table), "model"] <- "Total"
multicol.table[ , c(1, 2)] <- multicol.table[ , c(1, 2)] %>% round(2) # Round numeric values
xlsx::write.xlsx(multicol.table, "lm.VIF_SET_CFC.outl.del.imp.xlsx") # Export VIF results
# For regression
lm.table <- results.list[[1]]
lm.table <- lm.table[-c(grep("Zrr", lm.table[, "Var"], ignore.case = TRUE)), ] # Remove RR from results
rownames(lm.table) <- NULL # Reset rownames
lm.table[, "p.adj"] <- p.adjust(lm.table[ ,5], method = "fdr", n = nrow(lm.table)) # Do fdr-correction
lm.table[, "p.adj.sig"] <- sapply(lm.table[, "p.adj"], function(x) p.value.sig(x)) # Add column with corrected significance
lm.table[, "p.value.sig"] <- sapply(lm.table[, "p.value"], function(x) p.value.sig(x)) # Add column with uncorrected significance
lm.table[, "BF.evidence"] <- sapply(lm.table[, "BF"], function(x) BF.evidence(x)) # Add column with Bayes factor interpretation
xlsx::write.xlsx(lm.table, "lm.SET_CFC.outl.del.imp.xlsx") # Export results
# For partial correlations
corrs <- results.list[[2]]
corrs <- corrs[-c(grep("Zrr", corrs[, "var1"], ignore.case = TRUE), grep("Zrr", corrs[, "var2"], ignore.case = TRUE)), ] # Remove RR from results
rownames(corrs) <- NULL # Reset rownames
corrs[, "p.adj"] <- p.adjust(corrs[,4], method = "fdr", n = nrow(corrs)) # Do fdr-correction
corrs[, "p.adj.sig"] <- sapply(corrs[, "p.adj"], function(x) p.value.sig(x)) # Add column with corrected significance
corrs[, "p.value.sig"] <- sapply(corrs[, "p.value"], function(x) p.value.sig(x)) # Add column with uncorrected significance
corrs[, "cohen.d.mag"] <- sapply(corrs[, "cohen.d"], function(x) cohen.d.magnitude(x)) # Add column with cohen's d magnitude
xlsx::write.xlsx(corrs, "lm.corrs_SET_CFC.outl.del.imp.xlsx") # Export results


## Remove temporary variables
remove(Data)
remove(Data.list)
remove(p.value.sig)
remove(cohen.d.magnitude)
remove(BF.evidence)
remove(mi.regression)
remove(dependant)
remove(mod)
remove(fit.lm.imp)
remove(results.list)
remove(rsqr.imp)
remove(multicol.table)
remove(lm.table)
remove(corrs)