# Regressions -------------------------------------------------------------

## Description
# Standardizes variables, calculates eight multiple linear regression models from multiply imputed data 
# to predict delta-beta coupling from other stress responses (and in addition, 
# calculates variance-inflation factors, partial correlations, and Bayes factors)
# and exports the results to Excel.


## Packages
library(mice) # For analyzing imputed data (functions: lm.mids, complete, pool, pool.r.squared, and pool.scalar)
library(miceadds) # For analyzing imputed data (functions: micombine.cor, datlist_create, and scale_datlist)
library(magrittr) # For piping (function: %>%)
library(dplyr) # For data manipulation (function: filter)
library(broom) # For exporting lm results (function: )
library(car) # For variance inflation  test (function: vif)
library(xlsx) # For exporting to excel (function: write.xlsx)
library(psych) # For converting correlation coefficients to cohen's d (function: r2d)
library(BayesFactor) # For Bayesian statistics (functions: generalTestBF, and extractBF)
source('cohen.d.magnitude.R') # Custom function to check the magnitude of Cohen's d values
source('p.value.sig.R') # Custom function to check the significance of p.values
source('BF.evidence.R') # Custom function to check the interpretation of Bayes Factors

## Load data
load("SET_CFC.outl.del.imp.RData")
Data <- datlist_create(SET_CFC.outl.del.imp) # Create a datlist
Data.list <- scale_datlist(Data, # Standardize selected variables with a mean of 0 and standard deviation of 1
                           orig_var = c("RS_Frontal_Avg_dPAC_Z", "react_Frontal_Avg_dPAC_Z",
                                        "RS_Frontal_Avg_AAC_R", "react_Frontal_Avg_AAC_R",
                                        "RS_Parietal_Avg_dPAC_Z", "react_Parietal_Avg_dPAC_Z",
                                        "RS_Parietal_Avg_AAC_R", "react_Parietal_Avg_AAC_R",
                                        "LSAS", "Anx.1", "anx.react",
                                        "PEP.2", "pep.react",
                                        "RSA.2", "rsa.react",
                                        "RR.2", "rr.react",
                                        "Cortisol.1.log", "cort.react",
                                        "EnglishCompetence"), 
                           trafo_var = c("ZRS_Frontal_Avg_dPAC_Z", "Zreact_Frontal_Avg_dPAC_Z",
                                         "ZRS_Frontal_Avg_AAC_R", "Zreact_Frontal_Avg_AAC_R",
                                         "ZRS_Parietal_Avg_dPAC_Z", "Zreact_Parietal_Avg_dPAC_Z",
                                         "ZRS_Parietal_Avg_AAC_R", "Zreact_Parietal_Avg_AAC_R",
                                         "ZLSAS", "ZAnx.1", "Zanx.react",
                                         "ZPEP.2", "Zpep.react",
                                         "ZRSA.2", "Zrsa.react",
                                         "ZRR.2", "Zrr.react",
                                         "ZCortisol.1.log", "Zcort.react",
                                         "ZEnglishCompetence"))
Data <- datlist2mids(Data.list) # Convert datlist back to a mids

# Initialize variables for Bayesian statistics
Data_long <- mice::complete(Data, action = "long") # Transform mids into long dataset
colnames(Data_long)[1] <- "imp" # Change the ".imp" variable into "imp"
m <- Data$m # Number of imputions
n.obs <-Data_long %>% filter(imp == 1) %>% nrow() # Numbers of observations in the imputed dataset


### Regression models

### Model 1
# Predicts baseline frontal phase-amplitude coupling from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 1
## Specify dependant variable for partial correlations
dependant <- "ZRS_Frontal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- lm.mids(ZRS_Frontal_Avg_dPAC_Z ~ ZLSAS + ZAnx.1 + ZPEP.2 + ZRSA.2 + 
                        ZRR.2 + ZCortisol.1.log, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- sum.lm.imp # Save regression table
corrs <- corr.table # Save correlation table
multicol.table <- multicol.table.2 # Save multicollinearity
rsqr.imp <- pool.rsqr.imp # Save R-squared results


### Model 2
# Predicts baseline parietal phase-amplitude coupling from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 2
## Specify dependant variable for partial correlations
dependant <- "ZRS_Parietal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- lm.mids(ZRS_Parietal_Avg_dPAC_Z ~ ZLSAS + ZAnx.1 + ZPEP.2 + ZRSA.2 + 
                        ZRR.2 + ZCortisol.1.log, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 3
# Predicts baseline frontal amplitude-amplitude correlation from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 3
## Specify dependant variable for partial correlations
dependant <- "ZRS_Frontal_Avg_AAC_R"
## Fit model
fit.lm.imp <- lm.mids(ZRS_Frontal_Avg_AAC_R ~ ZLSAS + ZAnx.1 + ZPEP.2 + ZRSA.2 + 
                        ZRR.2 + ZCortisol.1.log, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 4
# Predicts baseline parietal amplitude-amplitude correlation from trait social anxiety and 
# stress response baselines (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 4
## Specify dependant variable for partial correlations
dependant <- "ZRS_Parietal_Avg_AAC_R"
## Fit model
fit.lm.imp <- lm.mids(ZRS_Parietal_Avg_AAC_R ~ ZLSAS + ZAnx.1 + ZPEP.2 + ZRSA.2 + 
                        ZRR.2 + ZCortisol.1.log, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 5
# Predicts frontal phase-amplitude coupling reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 5
## Specify dependant variable for partial correlations
dependant <- "Zreact_Frontal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- lm.mids(Zreact_Frontal_Avg_dPAC_Z ~ ZLSAS +Zanx.react + Zpep.react + Zrsa.react + 
                        Zrr.react + Zcort.react, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 6
# Predicts parietal phase-amplitude coupling reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 6
## Specify dependant variable for partial correlations
dependant <- "Zreact_Parietal_Avg_dPAC_Z"
## Fit model
fit.lm.imp <- lm.mids(Zreact_Parietal_Avg_dPAC_Z ~ ZLSAS +Zanx.react + Zpep.react + Zrsa.react + 
                        Zrr.react + Zcort.react, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 7
# Predicts frontal amplitude-amplitude correlation reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 7
## Specify dependant variable for partial correlations
dependant <- "Zreact_Frontal_Avg_AAC_R"
## Fit model
fit.lm.imp <- lm.mids(Zreact_Frontal_Avg_AAC_R ~ ZLSAS + Zanx.react + Zpep.react + Zrsa.react + 
                        Zrr.react + Zcort.react, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results


### Model 8
# Predicts parietal amplitude-amplitude correlation reactivity from trait social anxiety and 
# stress response reactivity (state anxiety, pre-ejection period, respiratory sinus arrhythmia,
# respiratory rate, and cortisol).
## Specify model number
mod <- 8
## Specify dependant variable for partial correlations
dependant <- "Zreact_Parietal_Avg_AAC_R"
## Fit model
fit.lm.imp <- lm.mids(Zreact_Parietal_Avg_AAC_R ~ ZLSAS + Zanx.react + Zpep.react + Zrsa.react + 
                        Zrr.react + Zcort.react, data = Data)
## Pool regression results
pool.lm.imp <- pool(fit.lm.imp) # Pool
pool.rsqr.imp <- pool.r.squared(fit.lm.imp) %>% as.data.frame() # R-squared
pool.rsqr.imp[, "model"] <- mod # Add model number
sum.lm.imp <- summary(pool.lm.imp) # Summary
sum.lm.imp[, "Model"] <- mod # Save the lm model number
sum.lm.imp[, "Var"] <- rownames(sum.lm.imp) # Save the variable names
sum.lm.imp[, "Dep"] <- dependant # Save name of dependent variable
sum.lm.imp <- sum.lm.imp[-1, ] # Remove the intercept
## Check multicollinearity
multicol <- list(NA) # Initialize results list
# Compute VIF for each variable and imputed dataset
for (i in 1:length(fit.lm.imp$analyses)) {
  multicol[[i]] <- vif(fit.lm.imp$analyses[[i]])
}
# Put all VIF's into dataframe
multicol.table.1 <- matrix(nrow = I(nrow(sum.lm.imp)-1), ncol = length(multicol))
for (i in 1:nrow(multicol.table.1)) {
  for (j in 1:ncol(multicol.table.1))
    multicol.table.1[i, j] <- multicol[[j]][[i]]
}
rownames(multicol.table.1) <- rownames(sum.lm.imp)[-1] # Set rownames of variables
# Compute range of VIFs per variable
multicol.table.2 <- multicol.table.1[, c(1:2)] # Initialize new results matrix with two columns
multicol.table.2[, 1] <- apply(multicol.table.1, 1, min) # Calculate min VIF
multicol.table.2[, 2] <- apply(multicol.table.1, 1, max) # Calculate max VIF
multicol.table.2 <- t(multicol.table.2) %>% as.data.frame() # Transpose matrix and save as dataframe
rownames(multicol.table.2) <- c("min_VIF", "max_VIF") # Set descriptive rownames
multicol.table.2 <- multicol.table.2 %>% t() %>% as.data.frame() # Save as transposed dataframe
multicol.table.2[, "var"] <- rownames(multicol.table.2) # Save variable names
rownames(multicol.table.2) <- NULL # Reset rownames
multicol.table.2[ , "model"] <- mod # Save model name
## Partial correlations
# Get predictor variable names
a <- fit.lm.imp[[1]] %>% as.character() # Extract the call for fit.lm.imp
a <- a[2] # Select only the actual call
b <- strsplit(a, " ") # Split the call on spaces to get individual variables
c <- unlist(b) # Unlist to get character vectors
d <- c[!c %in% c("+", "*", "~", "(", ")")] # Remove entries containing special characters: +, *, ~, (, and )
e <- d[-c(1)] # Remove the first entry
f <- unique(e) # Remove double entries
pred <- f
# Loop for all variables in the regression results, skipping the intercept
corr <- list(NA) # Initialize results list
for (i in 1:length(pred)) {
  # Compute correlation between dependent variable and single predictor, correcting for all other predictors
  form <- paste(pred[-i], collapse = "+")  # Create single character string of all predictors to be partialled out
  corr.temp <- micombine.cor(Data, variables = c(dependant, pred[i]), 
                             partial = as.formula(paste("~", form)))
  corr[[i]] <- corr.temp[1, ] # Save only the first row (second row is the same)
}
# Put the correlation results in a table
# Extract results from list
corr.table <- sapply(corr, function(x) {
  c(var1 = levels(x$variable1)[1],
    var2 = levels(x$variable1)[2],
    rho = x$r,
    p.value = x$p)
})
# Save the results as a dataframe
corr.table <- t(corr.table) %>% as.data.frame(stringsAsFactors = FALSE) # Transpose the dataframe
corr.table[, 3:4] <- lapply(corr.table[, 3:4], function(x) as.numeric(as.character(x))) %>% 
  lapply(function(x) round(x, 5)) # Set the numeric columns to numeric and round to 5 decimals
corr.table[, "cohen.d"] <- r2d(corr.table[, "rho"]) # Compute cohen's d
corr.table[, "Model"] <- mod # Save the lm model number
## Bayes factors
# Initialize variables
BFest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the BayesFactors estimates
varest <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = m) # Matrix to put the variance of the dependent variable
est <- matrix(NA, nrow = nrow(sum.lm.imp), ncol = 1) # Matrix to put the pooled estimates
# Loop over all imputed Data_longs
# Loop over all imputed datasets
for (j in 1:m) { # For all imputed Data_longs
  subdata <- Data_long %>% filter(imp == j) # Select imputed Data_long
  BF <- generalTestBF(formula = as.formula(fit.lm.imp[["call"]][["formula"]]), # Calculate BayesFactor
                      data = subdata, whichModels = "bottom", progress = FALSE)
  BFest[, j] <- extractBF(BF, onlybf = TRUE) # Extract only the BayesFactors
  # Calculate the standard error of the estimate per variable (necessary for pooling)
  for (i in 1:nrow(sum.lm.imp)) { # Loop over all variables/models
    if (grepl(":", sum.lm.imp[i, "Var"])) { # If the variable contains an interaction
      Var <- sub("\\:.*", "", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Select the variable name before ":"
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else if (grepl("SexFemale", sum.lm.imp[i, "Var"])) { # If the main effect contains Sex
      Var <- sub("SexFemale", "Sex", grep(":", sum.lm.imp[i, "Var"], value = TRUE)) # Rename SexFemale to Sex
      varest[i, j] <- mean(c( var(subdata[, Var]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    } else { # For 'normal' variables
      varest[i, j] <- mean(c( var(subdata[, sum.lm.imp[i, "Var"]]), var(subdata[, sum.lm.imp[i, "Dep"]]) )) / 
        n.obs 
    }
  }
}
# Pool the descriptives into one estimate with three decimals for all vars
for (i in 1:nrow(sum.lm.imp)) { # For every variable
  est[i, 1] <- pool.scalar(BFest[i, ], varest[i, ], n = n.obs, k = 1)[["qbar"]] %>% unlist() %>% round(3)
}
# Add bayes factors to dataframe
sum.lm.imp[, "BF"] <- est
# Save results
rownames(sum.lm.imp) <- NULL # Reset rownames of regression table
lm.table <- rbind(lm.table, sum.lm.imp) # Save regression table
corrs <- rbind(corrs, corr.table) # Save correlation table
multicol.table <- rbind(multicol.table, multicol.table.2) # Save multicollinearity
rsqr.imp <- rbind(rsqr.imp, pool.rsqr.imp) # Save R-squared results



### Export VIF and R-squared
# For R-squared
rownames(rsqr.imp) <- NULL # Reset rownames
write.xlsx(rsqr.imp, "lm.rsqr_SET_CFC.outl.del.imp.xlsx") # Export R-squared results
# For VIF
rownames(multicol.table) <- NULL # Reset rownames
multicol.table <- multicol.table[-c(grep("Zrr", multicol.table[, "var"], ignore.case = TRUE)), ] # Remove RR from results
multicol.table[I(nrow(multicol.table)+1), "min_VIF"] <- multicol.table[, "min_VIF"] %>% min() # Add overall min in a new row
multicol.table[nrow(multicol.table), "max_VIF"] <- multicol.table[-nrow(multicol.table), "max_VIF"] %>% max() # Add overall max
multicol.table[nrow(multicol.table), "model"] <- "Total"
multicol.table[ , c(1, 2)] <- multicol.table[ , c(1, 2)] %>% round(2) # Round numeric values
write.xlsx(multicol.table, "lm.VIF_SET_CFC.outl.del.imp.xlsx") # Export VIF results

### FDR-correction
# For regression
lm.table <- lm.table[-c(grep("Zrr", lm.table[, "Var"], ignore.case = TRUE)), ] # Remove RR from results
rownames(lm.table) <- NULL # Reset rownames
lm.table[, "p.adj"] <- p.adjust(lm.table[ ,5], method = "fdr", n = nrow(lm.table)) # Do fdr-correction
lm.table[, "p.adj.sig"] <- sapply(lm.table[, "p.adj"], function(x) p.value.sig(x)) # Add column with corrected significance
lm.table[, "p.value.sig"] <- sapply(lm.table[, "p.value"], function(x) p.value.sig(x)) # Add column with uncorrected significance
lm.table[, "BF.evidence"] <- sapply(lm.table[, "BF"], function(x) BF.evidence(x)) # Add column with Bayes factor interpretation
write.xlsx(lm.table, "lm.SET_CFC.outl.del.imp.xlsx") # Export results
# For partial correlations
corrs <- corrs[-c(grep("Zrr", corrs[, "var1"], ignore.case = TRUE), grep("Zrr", corrs[, "var2"], ignore.case = TRUE)), ] # Remove RR from results
rownames(corrs) <- NULL # Reset rownames
corrs[, "p.adj"] <- p.adjust(corrs[,4], method = "fdr", n = nrow(corrs)) # Do fdr-correction
corrs[, "p.adj.sig"] <- sapply(corrs[, "p.adj"], function(x) p.value.sig(x)) # Add column with corrected significance
corrs[, "p.value.sig"] <- sapply(corrs[, "p.value"], function(x) p.value.sig(x)) # Add column with uncorrected significance
corrs[, "cohen.d.mag"] <- sapply(corrs[, "cohen.d"], function(x) cohen.d.magnitude(x)) # Add column with cohen's d magnitude
write.xlsx(corrs, "lm.corrs_SET_CFC.outl.del.imp.xlsx") # Export results


## Remove temporary variables
remove(Data)
remove(fit.lm.imp)
remove(pool.lm.imp)
remove(pool.rsqr.imp)
remove(rsqr.imp)
remove(sum.lm.imp)
remove(p.value.sig)
remove(multicol.table)
remove(multicol.table.1)
remove(multicol.table.2)
remove(corr)
remove(corr.table)
remove(corr.temp)
remove(dependant)
remove(i)
remove(j)
remove(multicol)
remove(corrs)
remove(lm.table)
remove(mod)
remove(Data.list)
remove(a, b, c, d, e, f)
remove(form)
remove(pred)
remove(cohen.d.magnitude)
remove(BF.evidence)
remove(m)
remove(Data_long)
remove(subdata)
remove(BF)
remove(n.obs)
remove(BFest)
remove(varest)
remove(est)
