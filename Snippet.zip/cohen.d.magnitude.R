# Custom function to check the magnitude of Cohen's d values (based on Cohen, 1988)
cohen.d.magnitude <- function(x) {
  x <- abs(x) # Remove minus signs
  if (x < 0.2) {
    y <- "negligible"
  } else if (x < 0.5) {
    y <- "small"
  } else if (x < 0.8) {
    y <- "medium"
  } else {
    y <- "large"
  } 
}