# Custom function to check the significance of p.values (based on American Psychological Association)
p.value.sig <- function(x) {
  if (x < 0.001) {
    y <- "***"
  } else if (x < 0.01) {
    y <- "**"
  } else if (x < 0.05) {
    y <- "*"
  } else if (x < 0.1) {
    y <- "+"
  } else {
    y <- "not significant"
  } 
}